package enumerados

/**
 * enumerado para los movimientos posibles
 */
enum Movimiento :
   case NULO, IZQUIERDA, ARRIBA, DERECHA, ABAJO
end Movimiento
   