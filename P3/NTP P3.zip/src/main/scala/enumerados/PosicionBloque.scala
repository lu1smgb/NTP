package enumerados

/**
 * enumerado para la posicion del bloque
 */
enum PosicionBloque :
   case PIE, TUMBADAX, TUMBADAY
end PosicionBloque
   