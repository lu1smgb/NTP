package enumerados

/**
 * enumerado del contenido del juego de movimiento del bloque
 */
enum Contenido :
   case SUELO , VACIO, PIEZA, SALIDA, LLEGADA
end Contenido   